<?php
/**
 * Plugin Name: Block Test
 * Description: This is a only testing purpose!
 * Plugin URI: #
 * Version: 1.0
 * Author: Dev
 * Author URI: #
 * Text Domain: block-test
 *
 * Elementor tested up to: 3.30.4
 *
 * @package block-test
 * @since   1.0
 */

if ( ! function_exists( 'wpdocs_enqueue_scripts' ) ) {
    function wpdocs_enqueue_scripts() {

        $file_path = dirname( __FILE__ ) . '/build/index.js';

        if ( ! file_exists( $file_path ) ) {
            return;
        }

        wp_enqueue_script(
            'react-block',
            plugins_url() . '/block-test/build/index.js',
            [
                'wp-blocks',
                'wp-editor',
                'wp-data',
                'wp-i18n',
            ],
            filemtime( $file_path ),
            true
        );

        wp_enqueue_style(
            'wpdocs-editor-styles',
            plugins_url( '/build/style-index.css', __FILE__ )
        );
    }
}
add_action( 'enqueue_block_editor_assets', 'wpdocs_enqueue_scripts' );

if ( ! function_exists( 'wpdocs_enqueue_stylesheets' ) ) {
    function wpdocs_enqueue_stylesheets() {
        wp_enqueue_style(
            'wpdocs-frontend-styles',
            plugins_url( '/build/style-index.css', __FILE__ )
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpdocs_enqueue_stylesheets' );
