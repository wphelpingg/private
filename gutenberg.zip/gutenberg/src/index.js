import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import { MediaUpload, RichText, InspectorControls, URLInputButton } from '@wordpress/block-editor';
import { Button, PanelBody, TextControl } from '@wordpress/components';
import Edit from './edit';
import save from './save';

import './style.scss';

registerBlockType( 'trypro/react-block', {
	title: __( 'block', 'test' ),
	category: 'common',
	attributes: {
		title: {
			type: 'string',
			source: 'html',
			selector: 'h2',
		},
		content: {
			type: 'string',
			source: 'html',
			selector: 'p',
			default: __( 'Hello React!', 'test' ),
		},
		imageUrl: {
			type: 'string',
			default: '',
		},
		buttonText: {
			type: 'string',
			default: __('Click Me', 'test'),
		},
		buttonUrl: {
			type: 'string',
			default: '#',
		}
		highlight: {
			type: 'boolean',
			default: false
		}
	},
	edit: Edit,
	save,
} );
