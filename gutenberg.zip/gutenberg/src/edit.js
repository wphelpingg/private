import { __ } from '@wordpress/i18n';
import { useBlockProps, RichText, InspectorControls } from '@wordpress/block-editor';
import { PanelBody, ToggleControl } from '@wordpress/components';

export default function Edit( { attributes, setAttributes } ) {
	const { content, highlight } = attributes;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Settings', 'test' ) }>
					<ToggleControl
						label={ __( 'Highlight Text', 'test' ) }
						checked={ highlight }
						onChange={ ( value ) => setAttributes( { highlight: value } ) }
					/>
				</PanelBody>
			</InspectorControls>

			<RichText
				{ ...useBlockProps( { className: `${highlight ? 'is-highlighted' : ''} custom-class` } ) }
				tagName="p"
				value={ content }
				onChange={ ( value ) => setAttributes( { content: value } ) }
				placeholder={ __( 'Write something…', 'test' ) }
			/>
		</>
	);
}
