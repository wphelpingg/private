import { useBlockProps, RichText } from '@wordpress/block-editor';

export default function save( { attributes } ) {
    const { content, highlight } = attributes;

    return (
        <RichText.Content
            { ...useBlockProps.save( { className: `${highlight ? 'is-highlighted' : ''} custom-class` } ) }
            tagName="p"
            value={ content }
        />
    );
}
