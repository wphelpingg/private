// Variables
const { src, dest, watch, parallel } = require('gulp');
const browserSync = require('browser-sync').create();
const concat = require('gulp-concat');
const terser = require('gulp-terser');
const cleanCSS = require('gulp-clean-css');
const sourcemaps = require('gulp-sourcemaps');
const dartSass = require('gulp-dart-sass');
const header = require('gulp-header'); // keep if you use it elsewhere

// Compile vendor styles
function vendorsTask() {
  return src('includes/widgets/assets/css/*.css')
    .pipe(sourcemaps.init())
    //.pipe(dartSass().on('error', dartSass.logError))
    //.pipe(dest('css')) // concatinated css file
    .pipe(concat('vendors.min.css'))
    .pipe(cleanCSS({ level: 2 }))
    .pipe(sourcemaps.write('.'))
    .pipe(dest('includes/widgets/assets/css'))
    .pipe(browserSync.stream());
}

// Concat + minify vendor JS
function concatVendorsTask() {
  return src('includes/widgets/assets/js/*.js')
    .pipe(concat('vendors.min.js'))
    .pipe(terser({ output: { comments: /^!/ } }))
    .pipe(dest('includes/widgets/assets/js'))
    .pipe(browserSync.stream());
}

// BrowserSync
function browserSyncTask() {
  browserSync.init({
    watch: true,
    online: true,
    server: { baseDir: './' }
  });
}

// Watch files
function watchTask() {
  watch('includes/widgets/assets/css/*.css', vendorsTask); 
  watch('includes/widgets/assets/js/*.js', concatVendorsTask);
}

// Default task
exports.default = parallel(
  browserSyncTask,
  vendorsTask,
  concatVendorsTask,
  watchTask
);
